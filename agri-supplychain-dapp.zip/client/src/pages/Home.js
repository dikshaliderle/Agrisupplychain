import React from "react";

const Home = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">Welcome to Agri Supply Chain</h1>
      <p className="mt-2">Track your food with blockchain security.</p>
    </div>
  );
};

export default Home;