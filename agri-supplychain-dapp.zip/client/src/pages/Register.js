import React, { useState } from "react";

const Register = () => {
  const [role, setRole] = useState("Farmer");

  return (
    <div className="p-6 max-w-md mx-auto">
      <h2 className="text-2xl font-bold">Register</h2>
      <form className="mt-4 flex flex-col gap-4">
        <input type="text" placeholder="Name" className="p-2 border rounded" />
        <input type="email" placeholder="Email" className="p-2 border rounded" />
        <input type="password" placeholder="Password" className="p-2 border rounded" />
        <select value={role} onChange={(e) => setRole(e.target.value)} className="p-2 border rounded">
          <option value="Farmer">Farmer</option>
          <option value="Dealer">Dealer</option>
          <option value="Customer">Customer</option>
        </select>
        <button className="bg-green-600 text-white p-2 rounded">Register</button>
      </form>
    </div>
  );
};

export default Register;